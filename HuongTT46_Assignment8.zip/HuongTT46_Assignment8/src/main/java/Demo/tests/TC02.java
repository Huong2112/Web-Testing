package Demo.tests;

import Demo.core.BaseTest;
import Demo.pages.CustomerPage;
import org.testng.Assert;
import org.testng.annotations.Test;
import Demo.pages.CustomerListPage;
import Demo.pages.LoginPage;
import Demo.pages.MenuPage;

public class TC02 extends BaseTest {
    @Test
    public void test(){
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.navigateToLogin("https://magento-demo.mageplaza.com/admin/admin/");
        loginPage.login("mageplaza", "demo123");

        MenuPage menuPage = new MenuPage(getDriver());
        menuPage.clickToMenuCustomer();
        menuPage.clickToMenuAllCustomers();

        CustomerListPage customerListPage = new CustomerListPage(getDriver());
        customerListPage.clickToAddNewCustomer();

        CustomerPage customerPage = new CustomerPage(getDriver());
        customerPage.createNewCustomer("auto2","demo2","huongtt42@gmail.com");

        Assert.assertTrue(customerListPage.verifyMessage("You saved the customer."));

    }
}
